# Write with Us

An AI card-message assistant embedded on [Quillingcard.com](https://quillingcard.com). Helps shoppers write personalized greeting card messages, right on the product page.

**Live test link:** https://writer-6vn.pages.dev/

## Repo structure

```
shopify-widget/         → the widget snippet pasted into Shopify's theme.liquid
cloudflare-worker/       → backend proxy script that securely calls OpenAI
standalone-preview/      → standalone version of the widget (used for the live test link above)
docs/                   → full developer handoff (setup steps, architecture, cost breakdown)
```

## Quick start

1. Read `docs/DEVELOPER_HANDOFF.md` (or the `.docx` version) first — it covers the full architecture and setup steps.
2. `shopify-widget/quillingcard-writing-assistant.html` gets pasted into Shopify's `theme.liquid`.
3. `cloudflare-worker/cloudflare-worker.js` gets deployed as a Cloudflare Worker (holds the OpenAI key securely).
4. `standalone-preview/index.html` can be deployed to Cloudflare Pages for a shareable demo link, independent of Shopify.

## How it works

```
Shopper's browser (widget)
        │  POST { prompt }
        ▼
Cloudflare Worker  (holds the OpenAI key as a secret)
        │
        ▼
OpenAI API (gpt-4o-mini)
        │
        ▼
Response flows back and displays in the widget
```

## Cost

Realistic total: **$0–$2/month** at current traffic (OpenAI + Cloudflare free tiers cover nearly all of it).
